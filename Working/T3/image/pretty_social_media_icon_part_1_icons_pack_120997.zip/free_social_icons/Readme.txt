

	Thanks for downloading my free social icons :)
	

	----------------------------------------------


	If you downloaded these icons outside from deviantart server please notify it to me.

	Credit me if you use this icons in any project.

	----------------------------------------------


	thanks,


	Manuel L�pez.